let api_key = "456c230f8275e5f94cdb2dd0fc5a4e69";

let img_url = "https://image.tmdb.org/t/p/w500";  //to request images
let original_img_url = "https://image.tmdb.org/t/p/original";         //give movie image in original resolution for background purpose
let genres_list_http = "https://api.themoviedb.org/3/genre/movie/list?";  //to get all movies genre list
let movie_genres_http = "https://api.themoviedb.org/3/discover/movie?";  //to get movies data
let movie_detail_http = "https://api.themoviedb.org/3/movie";