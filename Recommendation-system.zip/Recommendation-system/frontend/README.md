To run the server :
```
$ npm isntall
$ npm start
```